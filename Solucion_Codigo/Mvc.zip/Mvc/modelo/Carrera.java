package modelo;

import java.io.Serializable;
import java.util.ArrayList;

public class Carrera implements Serializable {
    private String nombre;
    private int cupos;
    private String tipoAdmision;
    private double puntajeMinimo;
    private ArrayList<Postulante> postulantes;

    public Carrera(String nombre, int cupos, String tipoAdmision, double puntajeMinimo) {
        this.nombre = nombre;
        this.cupos = cupos;
        this.tipoAdmision = tipoAdmision;
        this.puntajeMinimo = puntajeMinimo;
        this.postulantes = new ArrayList<>();
    }

    public String getNombre() {
        return nombre;
    }

    public int getCupos() {
        return cupos;
    }

    public String getTipoAdmision() {
        return tipoAdmision;
    }

    public double getPuntajeMinimo() {
        return puntajeMinimo;
    }

    public ArrayList<Postulante> getPostulantes() {
        return postulantes;
    }

    public void agregarPostulante(Postulante p) {
        postulantes.add(p);
    }

    @Override
    public String toString() {
        return nombre + " (" + tipoAdmision + ")";
    }
}
