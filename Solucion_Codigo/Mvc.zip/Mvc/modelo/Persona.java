package modelo;

import java.io.Serializable;

public class Persona implements Serializable {
    protected String cedula;
    protected String nombre;

    public Persona(String cedula, String nombre) {
        this.cedula = cedula;
        this.nombre = nombre;
    }

    public String getCedula() {
        return cedula;
    }

    public String getNombre() {
        return nombre;
    }

    public String mostrarInformacion() {
        return nombre + " (" + cedula + ")";
    }
}
